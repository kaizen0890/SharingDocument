#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <fstream> // lam viec voi file text
#include <sstream>

#include "opencv2\core\core.hpp"
#include "opencv2\contrib\contrib.hpp"
#include "opencv2\highgui\highgui.hpp"
#include "opencv2\imgproc\imgproc.hpp"
#include "opencv2\wavelib\wavelet2d.h"


#include <msclr/marshal_cppstd.h>


using namespace System::Runtime::InteropServices;
using namespace cv;
using namespace std;
using namespace System::Data;
using namespace System::Drawing;
using namespace msclr::interop;


namespace FaceRecognition {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for frm_createcsv
	/// </summary>
	public ref class frm_createcsv : public System::Windows::Forms::Form
	{
	public:
		frm_createcsv(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~frm_createcsv()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^  panel1;
	protected: 

	private: System::Windows::Forms::NumericUpDown^  nUD_notrain;

	private: System::Windows::Forms::Button^  btn_createcsv;


	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  btnPre;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::ComboBox^  cB_dataname;
	private: System::Windows::Forms::TextBox^  txt_csvname;
	private: System::Windows::Forms::PictureBox^  pB_test;
	private: System::Windows::Forms::PictureBox^  pB_train;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog;

	private: System::Windows::Forms::NumericUpDown^  nUD_number_image;


	private: System::Windows::Forms::NumericUpDown^  nUD_number_pepole;

	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label5;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->nUD_number_image = (gcnew System::Windows::Forms::NumericUpDown());
			this->nUD_number_pepole = (gcnew System::Windows::Forms::NumericUpDown());
			this->btn_createcsv = (gcnew System::Windows::Forms::Button());
			this->nUD_notrain = (gcnew System::Windows::Forms::NumericUpDown());
			this->txt_csvname = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->btnPre = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->cB_dataname = (gcnew System::Windows::Forms::ComboBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->pB_test = (gcnew System::Windows::Forms::PictureBox());
			this->pB_train = (gcnew System::Windows::Forms::PictureBox());
			this->openFileDialog = (gcnew System::Windows::Forms::OpenFileDialog());
			this->panel1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->nUD_number_image))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->nUD_number_pepole))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->nUD_notrain))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pB_test))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pB_train))->BeginInit();
			this->SuspendLayout();
			// 
			// panel1
			// 
			this->panel1->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->panel1->Controls->Add(this->nUD_number_image);
			this->panel1->Controls->Add(this->nUD_number_pepole);
			this->panel1->Controls->Add(this->btn_createcsv);
			this->panel1->Controls->Add(this->nUD_notrain);
			this->panel1->Controls->Add(this->txt_csvname);
			this->panel1->Controls->Add(this->label2);
			this->panel1->Controls->Add(this->label6);
			this->panel1->Controls->Add(this->label5);
			this->panel1->Controls->Add(this->btnPre);
			this->panel1->Controls->Add(this->label1);
			this->panel1->Controls->Add(this->cB_dataname);
			this->panel1->Controls->Add(this->label3);
			this->panel1->Location = System::Drawing::Point(21, 18);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(266, 250);
			this->panel1->TabIndex = 11;
			// 
			// nUD_number_image
			// 
			this->nUD_number_image->Location = System::Drawing::Point(192, 57);
			this->nUD_number_image->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {1000, 0, 0, 0});
			this->nUD_number_image->Name = L"nUD_number_image";
			this->nUD_number_image->Size = System::Drawing::Size(63, 20);
			this->nUD_number_image->TabIndex = 7;
			// 
			// nUD_number_pepole
			// 
			this->nUD_number_pepole->Location = System::Drawing::Point(192, 33);
			this->nUD_number_pepole->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {1000, 0, 0, 0});
			this->nUD_number_pepole->Name = L"nUD_number_pepole";
			this->nUD_number_pepole->Size = System::Drawing::Size(63, 20);
			this->nUD_number_pepole->TabIndex = 7;
			this->nUD_number_pepole->ValueChanged += gcnew System::EventHandler(this, &frm_createcsv::nUD_number_pepole_ValueChanged);
			// 
			// btn_createcsv
			// 
			this->btn_createcsv->Location = System::Drawing::Point(34, 189);
			this->btn_createcsv->Name = L"btn_createcsv";
			this->btn_createcsv->Size = System::Drawing::Size(182, 45);
			this->btn_createcsv->TabIndex = 0;
			this->btn_createcsv->Text = L"Create CSV";
			this->btn_createcsv->UseVisualStyleBackColor = true;
			this->btn_createcsv->Click += gcnew System::EventHandler(this, &frm_createcsv::btn_createcsv_Click);
			// 
			// nUD_notrain
			// 
			this->nUD_notrain->Location = System::Drawing::Point(192, 81);
			this->nUD_notrain->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {1000, 0, 0, 0});
			this->nUD_notrain->Name = L"nUD_notrain";
			this->nUD_notrain->Size = System::Drawing::Size(63, 20);
			this->nUD_notrain->TabIndex = 7;
			// 
			// txt_csvname
			// 
			this->txt_csvname->Location = System::Drawing::Point(131, 105);
			this->txt_csvname->Name = L"txt_csvname";
			this->txt_csvname->Size = System::Drawing::Size(124, 20);
			this->txt_csvname->TabIndex = 5;
			this->txt_csvname->TextChanged += gcnew System::EventHandler(this, &frm_createcsv::txt_csvname_TextChanged);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(10, 109);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(70, 13);
			this->label2->TabIndex = 6;
			this->label2->Text = L"Csv file name";
			this->label2->Click += gcnew System::EventHandler(this, &frm_createcsv::label2_Click);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(10, 61);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(119, 13);
			this->label6->TabIndex = 6;
			this->label6->Text = L"Person images numbers";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(10, 37);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(83, 13);
			this->label5->TabIndex = 6;
			this->label5->Text = L"Person numbers";
			// 
			// btnPre
			// 
			this->btnPre->Location = System::Drawing::Point(34, 137);
			this->btnPre->Name = L"btnPre";
			this->btnPre->Size = System::Drawing::Size(182, 46);
			this->btnPre->TabIndex = 3;
			this->btnPre->Text = L"Split Data";
			this->btnPre->UseVisualStyleBackColor = true;
			this->btnPre->Click += gcnew System::EventHandler(this, &frm_createcsv::btnPre_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(10, 13);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(82, 13);
			this->label1->TabIndex = 6;
			this->label1->Text = L"Database name";
			// 
			// cB_dataname
			// 
			this->cB_dataname->FormattingEnabled = true;
			this->cB_dataname->Items->AddRange(gcnew cli::array< System::Object^  >(10) {L"CALTECH", L"CMU_PIE_C27OFF", L"CMU_PIE_C27ON", 
				L"CMU_PIE20", L"CMU_PIE68", L"FEI", L"FERET_130", L"FERET_150", L"FERET_550", L"FERET_810"});
			this->cB_dataname->Location = System::Drawing::Point(131, 8);
			this->cB_dataname->Name = L"cB_dataname";
			this->cB_dataname->Size = System::Drawing::Size(124, 21);
			this->cB_dataname->Sorted = true;
			this->cB_dataname->TabIndex = 4;
			this->cB_dataname->SelectedIndexChanged += gcnew System::EventHandler(this, &frm_createcsv::cB_dataname_SelectedIndexChanged);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(10, 85);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(157, 13);
			this->label3->TabIndex = 6;
			this->label3->Text = L"Person images numbers for train";
			// 
			// pB_test
			// 
			this->pB_test->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->pB_test->Location = System::Drawing::Point(586, 18);
			this->pB_test->Name = L"pB_test";
			this->pB_test->Size = System::Drawing::Size(250, 250);
			this->pB_test->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pB_test->TabIndex = 10;
			this->pB_test->TabStop = false;
			// 
			// pB_train
			// 
			this->pB_train->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->pB_train->Location = System::Drawing::Point(320, 18);
			this->pB_train->Name = L"pB_train";
			this->pB_train->Size = System::Drawing::Size(250, 250);
			this->pB_train->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pB_train->TabIndex = 9;
			this->pB_train->TabStop = false;
			// 
			// openFileDialog
			// 
			this->openFileDialog->FileName = L"openFileDialog1";
			this->openFileDialog->FileOk += gcnew System::ComponentModel::CancelEventHandler(this, &frm_createcsv::openFileDialog_FileOk);
			// 
			// frm_createcsv
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(878, 308);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->pB_train);
			this->Controls->Add(this->pB_test);
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"frm_createcsv";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"frm_createcsv";
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->nUD_number_image))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->nUD_number_pepole))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->nUD_notrain))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pB_test))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pB_train))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void btnPre_Click(System::Object^  sender, System::EventArgs^  e)
			 {
					 openFileDialog->Filter = "Image Files|*.bmp; *.jpg; *.png|All Files (*.*)|*.*||"; 
					 openFileDialog->Title = "Select a image file"; 
					 openFileDialog->InitialDirectory = "";
					 openFileDialog-> Multiselect = "True"; 
					 int number_of_files;
					 array<System::String^>^ filename_src; // array of filenames
					 if ( openFileDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK )  
					 {
						filename_src = openFileDialog->FileNames;
						number_of_files = openFileDialog->FileNames->Length;
					 }
					 else
						return;

					System::String^ OpenFileName;
					System::String^ SaveFileName, ^filename;	
	
					int number_pepole = (int) nUD_number_pepole->Value; 
					int number_image = (int) nUD_number_image->Value; 
				
					if (cB_dataname->Text ==  "CMU_PIE20")
					{
						for (int i = 0; i < number_pepole; i++)
						{
					
							for (int j = 0; j < number_image; j ++)
							{
								OpenFileName = filename_src[number_image*i+j];
								System::String^ path;
								path = System::IO::Path::GetDirectoryName(OpenFileName);
								OpenFileName = OpenFileName->Replace("\\","\\\\");
								path = path->Replace("\\","\\\\");
						
								char* imgname = (char*)Marshal::StringToHGlobalAnsi(OpenFileName).ToPointer();  // convert to kieu char lay ten filecho opencv
								Mat  src = cv::imread(imgname);
								filename = (number_image*i+j+1).ToString()+".bmp";
						
						
								if (((0<=j)&&(j<=14))||((j>=21)&&(j<=35))||((j>=45)&&(j<=58))||((j>=66)&&(j<=79))||((j>=87)&&(j<=100))||((j>=108)&&(j<=121))||((j>=129)&&(j<=142)))
								{
												
									SaveFileName  = path +"\\test\\" + filename;
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);

									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_test->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_test->Refresh();
								}
								else
								{
									SaveFileName  = path+"\\train\\" + filename;
							
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_train->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_train->Refresh();
								}
						
							}
					
						}
			
					}
					if (cB_dataname->Text ==  "CMU_PIE68")
					{
						for (int i = 0; i < number_pepole; i++)
						{
							for (int j = 0; j < number_image; j ++)
							{
								OpenFileName = filename_src[number_image*i+j];
								System::String^ path;
								path = System::IO::Path::GetDirectoryName(OpenFileName);
								OpenFileName = OpenFileName->Replace("\\","\\\\");
								path = path->Replace("\\","\\\\");
						
								char* imgname = (char*)Marshal::StringToHGlobalAnsi(OpenFileName).ToPointer();  // convert to kieu char lay ten filecho opencv
								Mat  src = cv::imread(imgname);
						
								filename = (number_image*i+j).ToString()+".bmp";
								if (((0<=j)&&(j<=14))||((j>=21)&&(j<=35))) // 30 for test
								{
									//SaveFileName  = path +"\\train\\" + filename;
									SaveFileName  = path +"\\test\\" + filename;// cu 15 anh train, 30 anh test
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_test->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_test->Refresh();
								}
								else
								{
									SaveFileName  = path +"\\train\\" + filename;// cu 15 anh train, 30 anh test
									//SaveFileName  = path +"\\test\\" + filename;
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_train->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_train->Refresh();
								}
							}
					
						}
				
					}
					if (cB_dataname->Text ==  "FERET_550")
					{
					
						for (int i = 0; i < number_pepole; i++)

						{
					
							for (int j = 0; j < number_image; j ++)
							{
								OpenFileName = filename_src[number_image*i+j];
								System::String^ path;
								path = System::IO::Path::GetDirectoryName(OpenFileName);
								OpenFileName = OpenFileName->Replace("\\","\\\\");
								path = path->Replace("\\","\\\\");
						
								char* imgname = (char*)Marshal::StringToHGlobalAnsi(OpenFileName).ToPointer();  // convert to kieu char lay ten filecho opencv
								Mat  src = cv::imread(imgname);
								filename = (number_image*i+j+1).ToString()+".bmp";

						
						
								if (j==0)
								{
						
									SaveFileName  = path +"\\test\\" + filename;
						
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_test->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_test->Refresh();
								}
								else
								{
									SaveFileName  = path +"\\train\\" + filename;
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_train->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_train->Refresh();
								}
							}
					
						}
				
					}
					if (cB_dataname->Text ==  "FERET_130")
					{
						for (int i = 0; i < number_pepole; i++)

						{
					
							for (int j = 0; j < number_image; j ++)
							{
								OpenFileName = filename_src[number_image*i+j];
								System::String^ path;
								path = System::IO::Path::GetDirectoryName(OpenFileName);
								OpenFileName = OpenFileName->Replace("\\","\\\\");
								path = path->Replace("\\","\\\\");
						
								char* imgname = (char*)Marshal::StringToHGlobalAnsi(OpenFileName).ToPointer();  // convert to kieu char lay ten filecho opencv
								Mat  src = cv::imread(imgname);
								filename = (number_image*i+j+1).ToString()+".bmp";
						
						
								if (j==1)
								{
						
									SaveFileName  = path +"\\test\\" + filename;
						
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_test->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_test->Refresh();
								}
								else
								{
									SaveFileName  = path +"\\train\\" + filename;
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_train->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_train->Refresh();
								}
							}
					
						}
				
					}
					if (cB_dataname->Text ==  "FERET_150")
					{
						for (int i = 0; i < number_pepole; i++)

						{
					
							for (int j = 0; j < number_image; j ++)
							{
								OpenFileName = filename_src[number_image*i+j];
								System::String^ path;
								path = System::IO::Path::GetDirectoryName(OpenFileName);
								OpenFileName = OpenFileName->Replace("\\","\\\\");
								path = path->Replace("\\","\\\\");
						
								char* imgname = (char*)Marshal::StringToHGlobalAnsi(OpenFileName).ToPointer();  // convert to kieu char lay ten filecho opencv
								//dataFile << imgname << "\n"; // Ghi ten file anh vao file va xuong dong
								Mat  src = cv::imread(imgname);
								filename = (number_image*i+j+1).ToString()+".bmp";
						
						
								if (j==0)//||(j==2)||(j==4))
								{
						
									SaveFileName  = path +"\\test\\" + filename;
						
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_test->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_test->Refresh();
								}
								else
								{
									SaveFileName  = path +"\\train\\" + filename;
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_train->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_train->Refresh();
								}
							}
					
						}
				
					}
					//////////////////////////////////////////////////////////////////////////////////////
					if (cB_dataname->Text ==  "FERET_810")
					{
						for (int i = 0; i < number_pepole; i++)

						{
					
							for (int j = 0; j < number_image; j ++)
							{
								OpenFileName = filename_src[number_image*i+j];
								System::String^ path;
								path = System::IO::Path::GetDirectoryName(OpenFileName);
								//lstBox->Items->Add(OpenFileName);
								OpenFileName = OpenFileName->Replace("\\","\\\\");
								path = path->Replace("\\","\\\\");
						
								char* imgname = (char*)Marshal::StringToHGlobalAnsi(OpenFileName).ToPointer();  // convert to kieu char lay ten filecho opencv
								//dataFile << imgname << "\n"; // Ghi ten file anh vao file va xuong dong
								Mat  src = cv::imread(imgname);
								filename = (number_image*i+j+1).ToString()+".bmp";
						
						
								if (j==0)//||(j==2)||(j==4))
								{
						
									SaveFileName  = path +"\\test\\" + filename;
						
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_test->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_test->Refresh();
								}
								else
								{
									SaveFileName  = path +"\\train\\" + filename;
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_train->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_train->Refresh();
								}
							}
					
						}
				
					}
					//////////////////////////////////////////
					if (cB_dataname->Text ==  "FEI")
					{
						for (int i = 0; i < number_pepole; i++)

						{
					
							for (int j = 0; j < number_image; j ++)
							{
								OpenFileName = filename_src[number_image*i+j];
								System::String^ path;
								path = System::IO::Path::GetDirectoryName(OpenFileName);
								//lstBox->Items->Add(OpenFileName);
								OpenFileName = OpenFileName->Replace("\\","\\\\");
								path = path->Replace("\\","\\\\");
						
								char* imgname = (char*)Marshal::StringToHGlobalAnsi(OpenFileName).ToPointer();  // convert to kieu char lay ten filecho opencv
								//dataFile << imgname << "\n"; // Ghi ten file anh vao file va xuong dong
								Mat  src = cv::imread(imgname);
								filename = (number_image*i+j+1).ToString()+".bmp";
						
						
								if (j==0)//||(j==2)||(j==4))
								{
						
									SaveFileName  = path +"\\train\\" + filename;
						
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_test->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_test->Refresh();
								}
								else
								{
									SaveFileName  = path +"\\test\\" + filename;
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_train->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_train->Refresh();
								}
							}
					
						}
				
					}
					//////////////////////CALTECH
					//////////////////////////////////////////
					if (cB_dataname->Text ==  "CALTECH")//CMU_PIE_C27OFF
					{
						for (int i = 0; i < number_pepole; i++)

						{
					
							for (int j = 0; j < number_image; j ++)
							{
								OpenFileName = filename_src[number_image*i+j];
								System::String^ path;
								path = System::IO::Path::GetDirectoryName(OpenFileName);
								//lstBox->Items->Add(OpenFileName);
								OpenFileName = OpenFileName->Replace("\\","\\\\");
								path = path->Replace("\\","\\\\");
						
								char* imgname = (char*)Marshal::StringToHGlobalAnsi(OpenFileName).ToPointer();  // convert to kieu char lay ten filecho opencv
								//dataFile << imgname << "\n"; // Ghi ten file anh vao file va xuong dong
								Mat  src = cv::imread(imgname);
								filename = (number_image*i+j+1).ToString()+".bmp";
						
						
								if (j==0)//||(j==2)||(j==4))
								{
						
									SaveFileName  = path +"\\train\\" + filename;
						
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_test->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_test->Refresh();
								}
								else
								{
									SaveFileName  = path +"\\test\\" + filename;
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_train->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_train->Refresh();
								}
							}
					
						}
				
					}
					//////////////////////////////////////////
					if (cB_dataname->Text ==  "CMU_PIE_C27OFF")//CMU_PIE_C27OFF
					{
						for (int i = 0; i < number_pepole; i++)

						{
					
							for (int j = 0; j < number_image; j ++)
							{
								OpenFileName = filename_src[number_image*i+j];
								System::String^ path;
								path = System::IO::Path::GetDirectoryName(OpenFileName);
								//lstBox->Items->Add(OpenFileName);
								OpenFileName = OpenFileName->Replace("\\","\\\\");
								path = path->Replace("\\","\\\\");
						
								char* imgname = (char*)Marshal::StringToHGlobalAnsi(OpenFileName).ToPointer();  // convert to kieu char lay ten filecho opencv
								//dataFile << imgname << "\n"; // Ghi ten file anh vao file va xuong dong
								Mat  src = cv::imread(imgname);
								filename = (number_image*i+j+1).ToString()+".bmp";
						
						
								if ((j==7)||(j==10)||(j==19)) // image number 8, 11, 20
								{
						
									SaveFileName  = path +"\\train\\" + filename;
						
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_test->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_test->Refresh();
								}
								else
								{
									SaveFileName  = path +"\\test\\" + filename;
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_train->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_train->Refresh();
								}
							}
					
						}
				
					}
					///////////////////////////////////////
					//////////////////////////////////////////
					if (cB_dataname->Text ==  "CMU_PIE_C27ON")//CMU_PIE_C27ON
					{
						for (int i = 0; i < number_pepole; i++)

						{
					
							for (int j = 0; j < number_image; j ++)
							{
								OpenFileName = filename_src[number_image*i+j];
								System::String^ path;
								path = System::IO::Path::GetDirectoryName(OpenFileName);
								//lstBox->Items->Add(OpenFileName);
								OpenFileName = OpenFileName->Replace("\\","\\\\");
								path = path->Replace("\\","\\\\");
						
								char* imgname = (char*)Marshal::StringToHGlobalAnsi(OpenFileName).ToPointer();  // convert to kieu char lay ten filecho opencv
								//dataFile << imgname << "\n"; // Ghi ten file anh vao file va xuong dong
								Mat  src = cv::imread(imgname);
								filename = (number_image*i+j+1).ToString()+".bmp";
						
						
								if ((j==0)||(j==7)||(j==10)||(j==19)) // image number 1, 8, 11, 20
								{
						
									SaveFileName  = path +"\\train\\" + filename;
						
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_test->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_test->Refresh();
								}
								else
								{
									SaveFileName  = path +"\\test\\" + filename;
									char* savename = (char*)Marshal::StringToHGlobalAnsi(SaveFileName).ToPointer();
									imwrite(savename,src);
									int row_s = (src.rows/4)*4;
									int col_s = (src.cols/4)*4;
									Mat src_s = Mat(row_s, col_s, src.type());
									resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

									pB_train->Image  = gcnew    //replacement of cvShowImage
									System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
									System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
									pB_train->Refresh();
								}
							}
					
						}
				
					}
					///////////////////////////////////////
			 }
private: System::Void cB_dataname_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e)
		 {
			
			if (cB_dataname->Text ==  "CMU_PIE20")
			{
				nUD_number_pepole->Value = 20; // number of person on database
				nUD_number_image->Value = 153; // number of images of each person on database
				nUD_notrain->Value = 53; // number images of each person for training
			}

			if (cB_dataname->Text ==  "CMU_PIE68")
			{
				nUD_number_pepole->Value = 68; // number of person on database
				nUD_number_image->Value = 45; // number of images of each person on database
				nUD_notrain->Value = 15; // number images of each person for training
			}

			if (cB_dataname->Text ==  "FERET_810")
			{
				nUD_number_pepole->Value = 810; // number of person on database
				nUD_number_image->Value = 2; // number of images of each person on database
				nUD_notrain->Value = 1; // number images of each person for training
			}
			if (cB_dataname->Text ==  "FERET_550")
			{
				nUD_number_pepole->Value = 550; // number of person on database
				nUD_number_image->Value = 2; // number of images of each person on database
				nUD_notrain->Value = 1; // number images of each person for training
			}

			if (cB_dataname->Text ==  "FERET_150")
			{
				nUD_number_pepole->Value = 150; // number of person on database
				nUD_number_image->Value = 2; // number of images of each person on database
				nUD_notrain->Value = 1; // number images of each person for training
			}
			if (cB_dataname->Text ==  "FERET_130")
			{
				nUD_number_pepole->Value = 130; // number of person on database
				nUD_number_image->Value = 6; // number of images of each person on database
				nUD_notrain->Value = 3; // number images of each person for training
			}
			if (cB_dataname->Text ==  "FEI")
			{
				nUD_number_pepole->Value = 200; // number of person on database
				nUD_number_image->Value = 2; // number of images of each person on database
				nUD_notrain->Value = 1; // number images of each person for training
			}

			if (cB_dataname->Text ==  "CALTECH")
			{
				nUD_number_pepole->Value = 26; // number of person on database
				nUD_number_image->Value = 5; // number of images of each person on database
				nUD_notrain->Value = 1; // number images of each person for training
			}
			if (cB_dataname->Text ==  "CMU_PIE_C27OFF")
			{
				nUD_number_pepole->Value = 68; // number of person on database
				nUD_number_image->Value = 21; // number of images of each person on database
				nUD_notrain->Value = 3; // number images of each person for training
			}
			if (cB_dataname->Text ==  "CMU_PIE_C27ON")
			{
				nUD_number_pepole->Value = 68; // number of person on database
				nUD_number_image->Value = 24; // number of images of each person on database
				nUD_notrain->Value = 4; // number images of each person for training
			}


			txt_csvname->Text= cB_dataname->Text;
		 }
private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void btn_createcsv_Click(System::Object^  sender, System::EventArgs^  e)
		 {
				System::String^ csvname;
				csvname ="..\\csvfiles\\" + txt_csvname->Text+".csv"; 
				marshal_context context2;
				LPCTSTR cstr1 = context2.marshal_as<const TCHAR*>(csvname);
				fstream dataFile; 
				dataFile.open(cstr1, ios::out | ios::app);
				if(dataFile.fail()) 
				{
					dataFile.open(cstr1, ios::out | ios::app);
				}
				// Open Image file
				openFileDialog->Filter = "Image Files|*.bmp; *.jpg; *.png|All Files (*.*)|*.*||"; 
				openFileDialog->Title = "Select a image file"; 
				openFileDialog->InitialDirectory = "";
				openFileDialog-> Multiselect = "True"; 
				int number_of_files;
				array<System::String^>^ filename_src; // array of filenames
				if ( openFileDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK )  
				{
				filename_src = openFileDialog->FileNames;
				number_of_files = openFileDialog->FileNames->Length;
				}
				else
				return;

				System::String^ OpenFileName;
				System::String^ step_str;
				int step = 0;
				while (step <number_of_files)
				{		 
						OpenFileName = filename_src[step];
						OpenFileName = OpenFileName->Replace("\\","\\\\");
						char* imgname = (char*)Marshal::StringToHGlobalAnsi(OpenFileName).ToPointer();
						int noperson = (int)nUD_notrain->Value;

						step_str = (step/noperson).ToString();
						char* label = (char*)Marshal::StringToHGlobalAnsi(step_str).ToPointer(); 
				
						dataFile << imgname << ";" << label << "\n";

						Mat src = cv::imread(imgname);
						Mat img;
						cvtColor( src, img, CV_BGR2GRAY ); imwrite(imgname,img);


						int row_s = (src.rows/4)*4;
						int col_s = (src.cols/4)*4;
						Mat src_s = Mat(row_s, col_s, src.type());
						resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);

						pB_test->Image  = gcnew    //replacement of cvShowImage
						System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
						System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
						pB_test->Refresh();
						step++;
				}

		 }
private: System::Void nUD_number_pepole_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void txt_csvname_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void openFileDialog_FileOk(System::Object^  sender, System::ComponentModel::CancelEventArgs^  e) {
		 }
};
}
