#pragma once

#include <iostream>
#include <fstream> // lam viec voi file text
#include <Windows.h>

#include "opencv2\core\core.hpp"
#include "opencv2\contrib\contrib.hpp"
#include "opencv2\highgui\highgui.hpp"
#include "opencv2\imgproc\imgproc.hpp"
#include "opencv2\wavelib\wavelet2d.h"

#include <msclr/marshal_cppstd.h>

#include <sstream>
#include <conio.h>


using namespace System::Runtime::InteropServices;
using namespace cv;
using namespace std;
using namespace System::Data;
using namespace System::Drawing;


// Tinh thoi gian
#define TIMER_INIT LARGE_INTEGER frequency;LARGE_INTEGER t1,t2;double elapsedTime;QueryPerformanceFrequency(&frequency);

// Use to start the performance timer /
#define TIMER_START QueryPerformanceCounter(&t1);

//** Use to stop the performance timer and output the result to the standard stream. Less verbose than \c TIMER_STOP_VERBOSE /
#define TIMER_STOP QueryPerformanceCounter(&t2);elapsedTime=(float)(t2.QuadPart-t1.QuadPart)/frequency.QuadPart;//std::wcout<<elapsedTime<<L" sec"<<endl;
//Ket thuc tinh thoi gian

static void read_csv(const string& filename, vector<Mat>& images, vector<int>& labels, char separator = ';') 
{
    std::ifstream file(filename.c_str(), ifstream::in);
    if (!file) 
	{
        string error_message = "No valid input file was given, please check the given filename.";
        CV_Error(CV_StsBadArg, error_message);
    }
    string line, path, classlabel;
    while (getline(file, line)) 
	{
        stringstream liness(line);
        getline(liness, path, separator);
        getline(liness, classlabel);
        if(!path.empty() && !classlabel.empty()) 
		{
            images.push_back(imread(path, 0));
            labels.push_back(atoi(classlabel.c_str()));
        }

    }
}

static Mat norm_0_255(InputArray _src) {
    Mat src = _src.getMat();
    // Create and return normalized image:
    Mat dst;
    switch(src.channels()) {
    case 1:
        cv::normalize(_src, dst, 0, 255, NORM_MINMAX, CV_8UC1);
        break;
    case 3:
        cv::normalize(_src, dst, 0, 255, NORM_MINMAX, CV_8UC3);
        break;
    default:
        src.copyTo(dst);
        break;
    }
    return dst;
}

namespace FaceRecognition {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for frm_train
	/// </summary>
	public ref class frm_train : public System::Windows::Forms::Form
	{
	public:
		frm_train(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~frm_train()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txt_xmlfile;
	protected: 
	private: System::Windows::Forms::TextBox^  txt_timetrain;
	private: System::Windows::Forms::ComboBox^  cB_typeofrecg;
	private: System::Windows::Forms::Button^  btn_opencsv;
	private: System::Windows::Forms::TextBox^  txt_csvfiles;


	private: System::Windows::Forms::OpenFileDialog^  openFileDialog;

	private: System::Windows::Forms::Button^  btnTrain;

	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;


	private: System::Windows::Forms::Label^  lb1;
	private: System::Windows::Forms::NumericUpDown^  numUD_component;
	private: System::Windows::Forms::ListBox^  lstBox;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txt_xmlfile = (gcnew System::Windows::Forms::TextBox());
			this->txt_timetrain = (gcnew System::Windows::Forms::TextBox());
			this->cB_typeofrecg = (gcnew System::Windows::Forms::ComboBox());
			this->btn_opencsv = (gcnew System::Windows::Forms::Button());
			this->txt_csvfiles = (gcnew System::Windows::Forms::TextBox());
			this->openFileDialog = (gcnew System::Windows::Forms::OpenFileDialog());
			this->btnTrain = (gcnew System::Windows::Forms::Button());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->lb1 = (gcnew System::Windows::Forms::Label());
			this->numUD_component = (gcnew System::Windows::Forms::NumericUpDown());
			this->lstBox = (gcnew System::Windows::Forms::ListBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numUD_component))->BeginInit();
			this->SuspendLayout();
			// 
			// txt_xmlfile
			// 
			this->txt_xmlfile->Location = System::Drawing::Point(127, 109);
			this->txt_xmlfile->Name = L"txt_xmlfile";
			this->txt_xmlfile->Size = System::Drawing::Size(489, 20);
			this->txt_xmlfile->TabIndex = 34;
			// 
			// txt_timetrain
			// 
			this->txt_timetrain->Location = System::Drawing::Point(544, 25);
			this->txt_timetrain->Name = L"txt_timetrain";
			this->txt_timetrain->Size = System::Drawing::Size(72, 20);
			this->txt_timetrain->TabIndex = 33;
			// 
			// cB_typeofrecg
			// 
			this->cB_typeofrecg->FormattingEnabled = true;
			this->cB_typeofrecg->Items->AddRange(gcnew cli::array< System::Object^  >(3) {L"Eigenface", L"Fisherface", L"LBPface"});
			this->cB_typeofrecg->Location = System::Drawing::Point(127, 28);
			this->cB_typeofrecg->Name = L"cB_typeofrecg";
			this->cB_typeofrecg->Size = System::Drawing::Size(121, 21);
			this->cB_typeofrecg->TabIndex = 32;
			this->cB_typeofrecg->Text = L"Eigenface";
			this->cB_typeofrecg->SelectedIndexChanged += gcnew System::EventHandler(this, &frm_train::cB_typeofrecg_SelectedIndexChanged);
			// 
			// btn_opencsv
			// 
			this->btn_opencsv->Location = System::Drawing::Point(583, 73);
			this->btn_opencsv->Name = L"btn_opencsv";
			this->btn_opencsv->Size = System::Drawing::Size(33, 23);
			this->btn_opencsv->TabIndex = 31;
			this->btn_opencsv->Text = L"...";
			this->btn_opencsv->UseVisualStyleBackColor = true;
			this->btn_opencsv->Click += gcnew System::EventHandler(this, &frm_train::btn_opencsv_Click);
			// 
			// txt_csvfiles
			// 
			this->txt_csvfiles->Location = System::Drawing::Point(127, 75);
			this->txt_csvfiles->Name = L"txt_csvfiles";
			this->txt_csvfiles->Size = System::Drawing::Size(450, 20);
			this->txt_csvfiles->TabIndex = 30;
			this->txt_csvfiles->TextChanged += gcnew System::EventHandler(this, &frm_train::txt_csvfiles_TextChanged);
			// 
			// openFileDialog
			// 
			this->openFileDialog->FileName = L"openFileDialog1";
			// 
			// btnTrain
			// 
			this->btnTrain->Location = System::Drawing::Point(171, 145);
			this->btnTrain->Name = L"btnTrain";
			this->btnTrain->Size = System::Drawing::Size(345, 51);
			this->btnTrain->TabIndex = 26;
			this->btnTrain->Text = L"Train";
			this->btnTrain->UseVisualStyleBackColor = true;
			this->btnTrain->Click += gcnew System::EventHandler(this, &frm_train::btnTrain_Click);
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(17, 223);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(85, 13);
			this->label8->TabIndex = 17;
			this->label8->Text = L"xmlfile pathname";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(17, 116);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(64, 13);
			this->label7->TabIndex = 19;
			this->label7->Text = L"xmlfile name";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(17, 78);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(67, 13);
			this->label4->TabIndex = 18;
			this->label4->Text = L"Csvfile name";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(17, 33);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(103, 13);
			this->label5->TabIndex = 20;
			this->label5->Text = L"Type of Recognition";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(465, 28);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(71, 13);
			this->label6->TabIndex = 23;
			this->label6->Text = L"Time Training";
			// 
			// lb1
			// 
			this->lb1->AutoSize = true;
			this->lb1->Location = System::Drawing::Point(267, 28);
			this->lb1->Name = L"lb1";
			this->lb1->Size = System::Drawing::Size(86, 13);
			this->lb1->TabIndex = 22;
			this->lb1->Text = L"No. Components";
			// 
			// numUD_component
			// 
			this->numUD_component->Location = System::Drawing::Point(355, 25);
			this->numUD_component->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {1000, 0, 0, 0});
			this->numUD_component->Name = L"numUD_component";
			this->numUD_component->Size = System::Drawing::Size(62, 20);
			this->numUD_component->TabIndex = 16;
			this->numUD_component->ValueChanged += gcnew System::EventHandler(this, &frm_train::numUD_component_ValueChanged);
			// 
			// lstBox
			// 
			this->lstBox->FormattingEnabled = true;
			this->lstBox->Location = System::Drawing::Point(127, 211);
			this->lstBox->Name = L"lstBox";
			this->lstBox->Size = System::Drawing::Size(489, 30);
			this->lstBox->TabIndex = 15;
			// 
			// frm_train
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(632, 276);
			this->Controls->Add(this->txt_xmlfile);
			this->Controls->Add(this->txt_timetrain);
			this->Controls->Add(this->cB_typeofrecg);
			this->Controls->Add(this->btn_opencsv);
			this->Controls->Add(this->txt_csvfiles);
			this->Controls->Add(this->btnTrain);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->lb1);
			this->Controls->Add(this->numUD_component);
			this->Controls->Add(this->lstBox);
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"frm_train";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"frm_train";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numUD_component))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnTrain_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				// Get the path to your CSV string 
				// convert from 'System::String ^' to 'std::string'
				if (txt_csvfiles->Text== "")
				{
					MessageBox::Show("Please select the csv file","Face recognition", MessageBoxButtons::OK,MessageBoxIcon::Asterisk);
					return;
				}
				
				if (txt_xmlfile->Text== "")
				{
					MessageBox::Show("Please put the name of xml file","Face recognition", MessageBoxButtons::OK,MessageBoxIcon::Asterisk);
					return;
				}
				msclr::interop::marshal_context context;
				std::string fn_csv = context.marshal_as<std::string>(txt_csvfiles->Text);
				// These vectors hold the images and corresponding labels.
				vector<Mat> images;
				vector<int> labels;
				// Read in the data. This can fail if no valid
				// input filename is given.
				try {
						read_csv(fn_csv, images, labels);
					} catch (cv::Exception& e) 
						{
							cerr << "Error opening file \"" << fn_csv << "\". Reason: " << e.msg << endl;
							// nothing more we can do
							exit(1);
						}
				// Quit if there are not enough images for this demo.
				if(images.size() <= 1) 
				{
					string error_message = "The Program needs at least 2 images to work. Please add more images to your data set!";
					CV_Error(CV_StsError, error_message);
				}
				// Eigenface training
				if (cB_typeofrecg->Text == L"Eigenface")
				{
					System::String^ name;
					int i = (int)numUD_component->Value;
					//Timer^ time;
					TIMER_INIT

					{	
						TIMER_START
						Ptr<FaceRecognizer> model = createEigenFaceRecognizer(i);
						model->train(images, labels);
						name = "..\\xmlfiles\\" + txt_xmlfile->Text + "_" + (i).ToString()+".xml";
						char* name1 = (char*)Marshal::StringToHGlobalAnsi(name).ToPointer();
						model->save(name1);
						TIMER_STOP
						
					}
					txt_timetrain->Text = elapsedTime.ToString()+" secs"; //frequency.QuadPart
					lstBox->Items->Add(name);
				}
				// Fisherface training
				if (cB_typeofrecg->Text == L"Fisherface")
				{
					System::String^ name;
					int i = (int)numUD_component->Value;
					TIMER_INIT

						{
							TIMER_START
							Ptr<FaceRecognizer> model = createFisherFaceRecognizer(i);
							model->train(images, labels);
							name = "..\\xmlfiles\\" + txt_xmlfile->Text + "_" + (i).ToString()+".xml";
							char* name1 = (char*)Marshal::StringToHGlobalAnsi(name).ToPointer();
							model->save(name1);
							TIMER_STOP
						}
					txt_timetrain->Text = elapsedTime.ToString()+" secs";
					lstBox->Items->Add(name);
				}
				//LBPface training
				if (cB_typeofrecg->Text == L"LBPface")
				{
					System::String^ name;
					//int i = (int)numUD_component->Value;
					TIMER_INIT

						{
							TIMER_START
							Ptr<FaceRecognizer> model = createLBPHFaceRecognizer();
							model->train(images, labels);
							name = "..\\xmlfiles\\" + txt_xmlfile->Text + ".xml";
							char* name1 = (char*)Marshal::StringToHGlobalAnsi(name).ToPointer();
							model->save(name1);
							TIMER_STOP
						}

					txt_timetrain->Text = elapsedTime.ToString()+" secs";
					lstBox->Items->Add(name);
				}
		
			 }
private: System::Void btn_opencsv_Click(System::Object^  sender, System::EventArgs^  e)
		 {
				openFileDialog->Filter = "CSV Files|*.csv|All Files (*.*)|*.*||"; 
				openFileDialog->Title = "Select a csv file"; 
				openFileDialog->InitialDirectory = "..\\csvfiles";
				
				System::String^ OpenFileName;
				if ( openFileDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK )  
				{
					OpenFileName = openFileDialog->FileName;
					OpenFileName = OpenFileName->Replace("\\","\\\\");
				}
				else
					return;
				txt_csvfiles->Text = OpenFileName;
		 }
private: System::Void cB_typeofrecg_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void numUD_component_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void txt_csvfiles_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}
