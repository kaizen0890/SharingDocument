// Face Recognition.cpp : main project file.

#include "stdafx.h"
#include "frm_main.h"

using namespace FaceRecognition;

[STAThreadAttribute]
int main(array<System::String ^> ^args)
{
	// Enabling Windows XP visual effects before any controls are created
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false); 

	// Create the main window and run it
	Application::Run(gcnew frm_main());
	return 0;
}
