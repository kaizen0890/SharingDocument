#pragma once

#include <iostream>
#include <fstream> 
#include <Windows.h>
#include<vector>

#include "opencv2\core\core.hpp"
#include "opencv2\contrib\contrib.hpp"
#include "opencv2\highgui\highgui.hpp"
#include "opencv2\imgproc\imgproc.hpp"
#include "opencv2\wavelib\wavelet2d.h"

#include <msclr/marshal_cppstd.h>

//#include <sstream>
//#include <conio.h>

using namespace System::Runtime::InteropServices;
using namespace cv;
using namespace std;
using namespace System::Data;
using namespace System::Drawing;


	// Tinh thoi gian
#define TIMER_INIT LARGE_INTEGER frequency;LARGE_INTEGER t1,t2;double elapsedTime;QueryPerformanceFrequency(&frequency);

// Use to start the performance timer 
#define TIMER_START QueryPerformanceCounter(&t1);

// Use to stop the performance timer and output the result to the standard stream. Less verbose than \c TIMER_STOP_VERBOSE 
#define TIMER_STOP QueryPerformanceCounter(&t2);elapsedTime=(float)(t2.QuadPart-t1.QuadPart)/frequency.QuadPart;//std::wcout<<elapsedTime<<L" sec"<<endl;
//Ket thuc tinh thoi gian

namespace FaceRecognition {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for frm_test
	/// </summary>
	public ref class frm_test : public System::Windows::Forms::Form
	{
	public:
		frm_test(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~frm_test()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::NumericUpDown^  nUD_component;
	protected: 
	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  lb1;
	private: System::Windows::Forms::Button^  btn_xml;
	private: System::Windows::Forms::TextBox^  txt_output;
	private: System::Windows::Forms::TextBox^  txt_xml;
	private: System::Windows::Forms::ComboBox^  cB_typerec;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::TextBox^  txt_time;
	private: System::Windows::Forms::TextBox^  txt_total;
	private: System::Windows::Forms::TextBox^  txt_falseface;
	private: System::Windows::Forms::TextBox^  txt_trueface;
	private: System::Windows::Forms::TextBox^  txt_noImage;
	private: System::Windows::Forms::TextBox^  txt_noPerson;
	private: System::Windows::Forms::ComboBox^  cB_dataname;

	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::PictureBox^  pB_src;
	private: System::Windows::Forms::Button^  btn_test;

	protected: 






	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->nUD_component = (gcnew System::Windows::Forms::NumericUpDown());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->lb1 = (gcnew System::Windows::Forms::Label());
			this->btn_xml = (gcnew System::Windows::Forms::Button());
			this->txt_output = (gcnew System::Windows::Forms::TextBox());
			this->txt_xml = (gcnew System::Windows::Forms::TextBox());
			this->cB_typerec = (gcnew System::Windows::Forms::ComboBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->openFileDialog = (gcnew System::Windows::Forms::OpenFileDialog());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->txt_time = (gcnew System::Windows::Forms::TextBox());
			this->txt_total = (gcnew System::Windows::Forms::TextBox());
			this->txt_falseface = (gcnew System::Windows::Forms::TextBox());
			this->txt_trueface = (gcnew System::Windows::Forms::TextBox());
			this->txt_noImage = (gcnew System::Windows::Forms::TextBox());
			this->txt_noPerson = (gcnew System::Windows::Forms::TextBox());
			this->cB_dataname = (gcnew System::Windows::Forms::ComboBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->pB_src = (gcnew System::Windows::Forms::PictureBox());
			this->btn_test = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->nUD_component))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pB_src))->BeginInit();
			this->SuspendLayout();
			// 
			// nUD_component
			// 
			this->nUD_component->Location = System::Drawing::Point(361, 72);
			this->nUD_component->Name = L"nUD_component";
			this->nUD_component->Size = System::Drawing::Size(46, 20);
			this->nUD_component->TabIndex = 42;
			this->nUD_component->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->nUD_component->ValueChanged += gcnew System::EventHandler(this, &frm_test::nUD_component_ValueChanged);
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(243, 308);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(64, 13);
			this->label11->TabIndex = 40;
			this->label11->Text = L"Time testing";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(243, 282);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(80, 13);
			this->label10->TabIndex = 39;
			this->label10->Text = L"Total test faces";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(243, 253);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(96, 13);
			this->label9->TabIndex = 38;
			this->label9->Text = L"Rate of false faces";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(243, 227);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(92, 13);
			this->label8->TabIndex = 41;
			this->label8->Text = L"Rate of true faces";
			// 
			// lb1
			// 
			this->lb1->AutoSize = true;
			this->lb1->Location = System::Drawing::Point(269, 77);
			this->lb1->Name = L"lb1";
			this->lb1->Size = System::Drawing::Size(86, 13);
			this->lb1->TabIndex = 37;
			this->lb1->Text = L"No. Components";
			// 
			// btn_xml
			// 
			this->btn_xml->Location = System::Drawing::Point(672, 105);
			this->btn_xml->Name = L"btn_xml";
			this->btn_xml->Size = System::Drawing::Size(32, 23);
			this->btn_xml->TabIndex = 36;
			this->btn_xml->Text = L"...";
			this->btn_xml->UseVisualStyleBackColor = true;
			this->btn_xml->Click += gcnew System::EventHandler(this, &frm_test::btn_xml_Click);
			// 
			// txt_output
			// 
			this->txt_output->Location = System::Drawing::Point(138, 149);
			this->txt_output->Name = L"txt_output";
			this->txt_output->Size = System::Drawing::Size(566, 20);
			this->txt_output->TabIndex = 34;
			// 
			// txt_xml
			// 
			this->txt_xml->Location = System::Drawing::Point(138, 108);
			this->txt_xml->Name = L"txt_xml";
			this->txt_xml->Size = System::Drawing::Size(527, 20);
			this->txt_xml->TabIndex = 35;
			this->txt_xml->TextChanged += gcnew System::EventHandler(this, &frm_test::txt_xml_TextChanged);
			// 
			// cB_typerec
			// 
			this->cB_typerec->FormattingEnabled = true;
			this->cB_typerec->Items->AddRange(gcnew cli::array< System::Object^  >(3) {L"Eigenface", L"Fisherface", L"LBPface"});
			this->cB_typerec->Location = System::Drawing::Point(138, 72);
			this->cB_typerec->Name = L"cB_typerec";
			this->cB_typerec->Size = System::Drawing::Size(121, 21);
			this->cB_typerec->TabIndex = 33;
			this->cB_typerec->Text = L"Eigenface";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(21, 149);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(82, 13);
			this->label7->TabIndex = 31;
			this->label7->Text = L"output file name";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(21, 113);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(67, 13);
			this->label4->TabIndex = 32;
			this->label4->Text = L"xml file name";
			// 
			// openFileDialog
			// 
			this->openFileDialog->FileName = L"openFileDialog1";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(21, 75);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(103, 13);
			this->label5->TabIndex = 30;
			this->label5->Text = L"Type of Recognition";
			// 
			// txt_time
			// 
			this->txt_time->Location = System::Drawing::Point(344, 305);
			this->txt_time->Name = L"txt_time";
			this->txt_time->Size = System::Drawing::Size(100, 20);
			this->txt_time->TabIndex = 25;
			this->txt_time->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// txt_total
			// 
			this->txt_total->Location = System::Drawing::Point(344, 279);
			this->txt_total->Name = L"txt_total";
			this->txt_total->Size = System::Drawing::Size(100, 20);
			this->txt_total->TabIndex = 24;
			this->txt_total->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// txt_falseface
			// 
			this->txt_falseface->Location = System::Drawing::Point(344, 250);
			this->txt_falseface->Name = L"txt_falseface";
			this->txt_falseface->Size = System::Drawing::Size(100, 20);
			this->txt_falseface->TabIndex = 29;
			this->txt_falseface->Text = L" ";
			this->txt_falseface->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// txt_trueface
			// 
			this->txt_trueface->Location = System::Drawing::Point(344, 224);
			this->txt_trueface->Name = L"txt_trueface";
			this->txt_trueface->Size = System::Drawing::Size(100, 20);
			this->txt_trueface->TabIndex = 28;
			this->txt_trueface->Text = L"           ";
			this->txt_trueface->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// txt_noImage
			// 
			this->txt_noImage->Location = System::Drawing::Point(622, 24);
			this->txt_noImage->Name = L"txt_noImage";
			this->txt_noImage->Size = System::Drawing::Size(43, 20);
			this->txt_noImage->TabIndex = 26;
			this->txt_noImage->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			// 
			// txt_noPerson
			// 
			this->txt_noPerson->Location = System::Drawing::Point(361, 24);
			this->txt_noPerson->Name = L"txt_noPerson";
			this->txt_noPerson->Size = System::Drawing::Size(46, 20);
			this->txt_noPerson->TabIndex = 27;
			this->txt_noPerson->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->txt_noPerson->TextChanged += gcnew System::EventHandler(this, &frm_test::txt_noPerson_TextChanged);
			// 
			// cB_dataname
			// 
			this->cB_dataname->FormattingEnabled = true;
			this->cB_dataname->Items->AddRange(gcnew cli::array< System::Object^  >(10) {L"CALTECH", L"CMU_PIE_C27OFF", L"CMU_PIE_C27ON", 
				L"CMU_PIE20", L"CMU_PIE68", L"FEI", L"FERET_130", L"FERET_150", L"FERET_550", L"FERET_810"});
			this->cB_dataname->Location = System::Drawing::Point(138, 24);
			this->cB_dataname->Name = L"cB_dataname";
			this->cB_dataname->Size = System::Drawing::Size(121, 21);
			this->cB_dataname->TabIndex = 23;
			this->cB_dataname->SelectedIndexChanged += gcnew System::EventHandler(this, &frm_test::cB_data_SelectedIndexChanged);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(442, 28);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(150, 13);
			this->label3->TabIndex = 22;
			this->label3->Text = L"No. Images per Person for test";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(293, 29);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(62, 13);
			this->label2->TabIndex = 21;
			this->label2->Text = L"No.Persons";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(21, 32);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(58, 13);
			this->label1->TabIndex = 20;
			this->label1->Text = L"Data types";
			// 
			// pB_src
			// 
			this->pB_src->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->pB_src->Location = System::Drawing::Point(504, 185);
			this->pB_src->Name = L"pB_src";
			this->pB_src->Size = System::Drawing::Size(200, 200);
			this->pB_src->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pB_src->TabIndex = 19;
			this->pB_src->TabStop = false;
			// 
			// btn_test
			// 
			this->btn_test->Location = System::Drawing::Point(24, 239);
			this->btn_test->Name = L"btn_test";
			this->btn_test->Size = System::Drawing::Size(173, 71);
			this->btn_test->TabIndex = 18;
			this->btn_test->Text = L"Test";
			this->btn_test->UseVisualStyleBackColor = true;
			this->btn_test->Click += gcnew System::EventHandler(this, &frm_test::btn_test_Click);
			// 
			// frm_test
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(724, 409);
			this->Controls->Add(this->nUD_component);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->lb1);
			this->Controls->Add(this->btn_xml);
			this->Controls->Add(this->txt_output);
			this->Controls->Add(this->txt_xml);
			this->Controls->Add(this->cB_typerec);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->txt_time);
			this->Controls->Add(this->txt_total);
			this->Controls->Add(this->txt_falseface);
			this->Controls->Add(this->txt_trueface);
			this->Controls->Add(this->txt_noImage);
			this->Controls->Add(this->txt_noPerson);
			this->Controls->Add(this->cB_dataname);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->pB_src);
			this->Controls->Add(this->btn_test);
			this->Name = L"frm_test";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"frm_test";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->nUD_component))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pB_src))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void cB_data_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) 
			 {
				 
				if (cB_dataname->Text ==  "CMU_PIE20")
				{
					txt_noPerson->Text = "20"; // number of persons in database
					txt_noImage->Text = "100"; // number of images of each person for testing
				
				}

				if (cB_dataname->Text ==  "CMU_PIE68")
				{
					txt_noPerson->Text = "68"; // number of persons in database
					txt_noImage->Text = "30"; // number of images of each person for testing
				}

				if (cB_dataname->Text ==  "FERET_810")
				{
					txt_noPerson->Text = "810"; // number of persons in database
					txt_noImage->Text = "1"; // number of images of each person for testing
				}
				if (cB_dataname->Text ==  "FERET_550")
				{
					txt_noPerson->Text = "550"; // number of persons in database
					txt_noImage->Text = "1"; // number of images of each person for testing
				}

				if (cB_dataname->Text ==  "FERET_150")
				{
					txt_noPerson->Text = "150"; // number of persons in database
					txt_noImage->Text = "1"; // number of images of each person for testing
				}
				if (cB_dataname->Text ==  "FERET_130")
				{
					txt_noPerson->Text = "130"; // number of persons in database
					txt_noImage->Text = "1"; // number of images of each person for testing
				}
				if (cB_dataname->Text ==  "FEI")
				{
					txt_noPerson->Text = "200"; // number of persons in database
					txt_noImage->Text = "1"; // number of images of each person for testing
				}

				if (cB_dataname->Text ==  "CALTECH")
				{
					txt_noPerson->Text = "26"; // number of persons in database
					txt_noImage->Text = "4"; // number of images of each person for testing
				}
				if (cB_dataname->Text ==  "CMU_PIE_C27OFF")
				{
					txt_noPerson->Text = "68"; // number of persons in database
					txt_noImage->Text = "18"; // number of images of each person for testing
				}
				if (cB_dataname->Text ==  "CMU_PIE_C27ON")
				{
					txt_noPerson->Text = "68"; // number of persons in database
					txt_noImage->Text = "20"; // number of images of each person for testing
				}

			
			 }
private: System::Void btn_xml_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			openFileDialog->Filter = "xml Files|*.xml|All Files (*.*)|*.*||"; 
			openFileDialog->Title = "Select a xml file"; 
			openFileDialog->InitialDirectory = "..\\xmlfiles";
				
			System::String^ OpenFileName;
			if ( openFileDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK )  
			{
				OpenFileName = openFileDialog->FileName;
				OpenFileName = OpenFileName->Replace("\\","\\\\");
			}
			else
				return;
			txt_xml->Text = OpenFileName;
		 }
private: System::Void btn_test_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
				if (txt_xml->Text== "")
				{
					MessageBox::Show("Please select the xml file","Face recognition", MessageBoxButtons::OK,MessageBoxIcon::Asterisk);
					return;
				}
				
				if (txt_output->Text== "")
				{
					MessageBox::Show("Please put the name of xml file","Face recognition", MessageBoxButtons::OK,MessageBoxIcon::Asterisk);
					return;
				}

				System::String ^ output_name = "..\\txtfiles\\" + txt_output->Text + ".txt";
				fstream dataFile; 
				// convert from 'System::String ^' to 'std::string'
				msclr::interop::marshal_context context;
				std::string output_name1 = context.marshal_as<std::string>(output_name);
				//msclr::interop::marshal_context context;
				std::string xmlname = context.marshal_as<std::string>(txt_xml->Text);
				dataFile.open(output_name1, ios::out | ios::app); 
				if(dataFile.fail()) 
				{ 
					dataFile.open(output_name1, ios::out | ios::app); 
				} 
				txt_output->Clear();
				txt_output->Text = output_name;
				dataFile << "False images list:" << "\n";
				//Open images file for testing
				openFileDialog->Filter = "Image Files|*.bmp; *.jpg; *.png|All Files (*.*)|*.*||"; 
				openFileDialog->Title = "Select a image file"; 
				openFileDialog->InitialDirectory = "";
				openFileDialog-> Multiselect = "True"; 
				int number_of_files;
				array<System::String^>^ filename_src; // array of filenames
				if ( openFileDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK )  
				{
					filename_src = openFileDialog->FileNames;
					number_of_files = openFileDialog->FileNames->Length;
				}
				else return;
				System::String^ OpenFileName;
				int no_com = (int)nUD_component->Value;
				const int number_pepole = System::Convert::ToInt32(txt_noPerson->Text);
				const int number_image = System::Convert::ToInt32(txt_noImage->Text);
				
				//int result[number_pepole];
				vector<int> result;

				int falsenumber = 0;
				int truenumber = 0;
				Ptr<FaceRecognizer> model;
				if (cB_typerec->Text == L"Eigenface") model = createEigenFaceRecognizer(no_com);
				if (cB_typerec->Text == L"Fisherface") model = createFisherFaceRecognizer(no_com);
				if (cB_typerec->Text == L"LBPface") model = createLBPHFaceRecognizer();
				model->load(xmlname);

				
				/*TIMER_INIT
					TIMER_START*/
						for (int i = 0; i < number_pepole; i++)
						{
							int truelabel = 0;
							for (int j = 0; j < number_image; j ++)
							{
						
								OpenFileName = filename_src[number_image*i+j];
								OpenFileName = OpenFileName->Replace("\\","\\\\");
								char* imgname = (char*)Marshal::StringToHGlobalAnsi(OpenFileName).ToPointer();  // convert to kieu char lay ten filecho opencv
								Mat  src = cv::imread(imgname);
								Mat testImg;
								cvtColor(src, testImg, CV_RGB2GRAY);
								
								//show image
								int row_s = (src.rows/4)*4;
								int col_s = (src.cols/4)*4;
								Mat src_s = Mat(row_s, col_s, src.type());
								resize(src, src_s, src_s.size(), 0, 0, INTER_LINEAR);	
								pB_src->Image  = gcnew   
								System::Drawing::Bitmap(src_s.size().width,src_s.size().height,src_s.step,
								System::Drawing::Imaging::PixelFormat::Format24bppRgb,(System::IntPtr) src_s.data);
								pB_src->Refresh();
								int testLabel = i;
								int predictedLabel = model->predict(testImg);
								
								
								if (predictedLabel == testLabel ) {truelabel++;}
								else
								{
									dataFile << imgname << "\n";
									falsenumber++;
								}
							}
							//result.at(i) = truelabel;
							result.push_back(truelabel);
						}
					/*TIMER_STOP*/
				truenumber = number_pepole*number_image - falsenumber;
				txt_trueface->Text = ((float)(100*truenumber)/(number_pepole*number_image)).ToString() + "%";
				txt_falseface->Text = ((float)(100*falsenumber)/(number_pepole*number_image)).ToString() + "%";
				/*txt_total->Text = (number_pepole*number_image).ToString();
				txt_time->Text = ((float)elapsedTime).ToString()+" secs";*/

				for (int i =0; i <number_pepole; i++)
				{
					char* i_str = (char*)Marshal::StringToHGlobalAnsi(i.ToString()).ToPointer();
					char* finalresult = (char*)Marshal::StringToHGlobalAnsi(result.at(i).ToString()).ToPointer();
					dataFile << finalresult  << "\n ";
				}

		 }
private: System::Void txt_xml_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void txt_noPerson_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void nUD_component_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}
